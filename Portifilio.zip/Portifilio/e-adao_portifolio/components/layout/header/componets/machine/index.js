import style from '../title/title.module.css'
import React, { useState, useEffect } from "react";

export function Machine({ text: fullText }) {
    const [text, setText] = useState("");
    const [index, setIndex] = useState(0);
    const [mostrarCursor, setMostrarCursor] = useState(false)

    useEffect(() => {
        setText(""); // Resetando o texto ao mudar a props.text
        setIndex(0);
    }, [fullText]);

    useEffect(() => {
        if (index < fullText?.length) {
            const timeout = setTimeout(() => {
                setText((prev) => prev + fullText[index]);
                setIndex((prev) => prev + 1);
            }, 115);
            return () => clearTimeout(timeout); // Limpa o timeout ao desmontar o componente
        }
    }, [index, fullText]);
    
    useEffect(() => {
        const intervaloCursor = setInterval(() => {
            setMostrarCursor((prev) => !prev)
        }, 350)
        return () => clearInterval(intervaloCursor)
    }, [])
    return (
    <>
        <h1 className={style.titleComp}>
            {text[0]}<span>{text[1]}</span>{text.slice(2, 7)}
            <span>{text[7]}</span>{text.slice(8, 12)}
            {mostrarCursor && <span>|</span>}
        </h1>
    </>
    );
}