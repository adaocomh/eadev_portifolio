import {useEffect, useRef, useState } from "react"
export default function slideContato({children}){
    const ref = useRef(null)
    const [visivel, setVisivel] = useState(false)
    useEffect(()=>{
        const observe = new IntersectionObserver(([entry]) => setVisivel(entry.isIntersecting), {threshold: 0.1})
        if(ref.current) observe.observe(ref.current)
            return () => observe.disconnect()
    }, [])
    return children(ref, visivel)
}