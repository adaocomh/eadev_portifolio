import Head from 'next/head'

import '../style/global.css'
import TelaIni from '../components/layout/header'
import Sobre from '../components/layout/meuObjetivo'
import AreaPrj from '../components/layout/projetos'
import FtPg from '../components/layout/footerContato'
import { MenuSuspenso } from './components/menu_suspenso'
export default function App(){
    return (
        <>
        <Head>
            <title>É. Adão Dev.</title>
            <meta name="description" content="É. Adão Dev. - Dev Front-end freelancer"/>
            <meta property="og:title" content="É. Adão Dev.(Portfólio)"/>
            <meta property="og:description" content="É. Adão Dev. - Dev Front-end freelancer"/>
            <meta property="og:image" content="imgs/self/IMG_2414 1.png" />
            <meta property="og:url" content="https://seusite.com" />
            <meta property="og:type" content="website" />
            <link rel="icon" href="imgs/self/IMG_2414 1.png"/>
        </Head>
        <MenuSuspenso/>
        <TelaIni/>
        <Sobre/>
        <AreaPrj/>
        <FtPg/>
        </>
    )
}