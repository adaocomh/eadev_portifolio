import React, { useState } from 'react'
import style from './menuSuspenso.module.css'

export function MenuSuspenso(){
    const [aberto, setAberto] = useState(false)
    const scrollSection = (id) => {
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "center" })
    }
    return (
        <div className={style.menuSuspenso}>
            <p  onClick={()=>{scrollSection("hdS1")}}>ⓒ Code by É. Adão</p>
            <nav>
                <button className={style.mnMobile} onClick={() => setAberto(!aberto)}>{aberto ? <img src={'/imgs/icons/cross.png'} alt="Menu" width={24} height={24}/> : <img src={'/imgs/icons/interface-2.png'} alt="Menu" width={24} height={24}/>}</button>
                <ul className={`${style.mn} ${aberto ? style.aberto : ''}`}>
                    <li className={style.dois} onClick={()=>{scrollSection("sS2")}} >Meu objetivo</li>
                    <li className={style.um} onClick={()=>{scrollSection("aPS2")}} >Projetos</li>
                    <li className={style.tres} onClick={()=>{scrollSection("footerS4")}} >Contato</li>
                </ul>
            </nav>
        </div>
    )
}